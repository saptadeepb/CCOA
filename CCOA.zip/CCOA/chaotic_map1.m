function chaos = chaotic_map1( chaos_type, max_iter, Value)

chaos = zeros(1, max_iter);
z(1) = 0.7; % Initial value

switch chaos_type
    case 'Chebyshev' 
        for i = 1:max_iter
            z(i+1) = cos(i * acos(z(i)));
            chaos(i) = ((z(i) + 1) * Value) / 2;
        end

    case 'Circle'
        a = 0.5;
        b = 0.2;
        for i = 1:max_iter
            z(i+1) = mod(z(i) + b - (a / (2 * pi)) * sin(2 * pi * z(i)), 1);
            chaos(i) = z(i) * Value;
        end

    case 'Gauss'
        for i = 1:max_iter
            if z(i) == 0
                z(i+1) = 0;
            else
                z(i+1) = mod(1 / z(i), 1);
            end
            chaos(i) = z(i) * Value;
        end

    case 'Iterative' 
        a = 0.7;
        for i = 1:max_iter
            z(i+1) = sin((a * pi) / z(i));
            chaos(i) = ((z(i) + 1) * Value) / 2;
        end

    case 'Logistic'
        a = 4;
        for i = 1:max_iter
            z(i+1) = a * z(i) * (1 - z(i));
            chaos(i) = z(i) * Value;
        end

    case 'Piecewise' 
        P = 0.4;
        for i = 1:max_iter
            if z(i) >= 0 && z(i) < P
                z(i+1) = z(i) / P;
            elseif z(i) >= P && z(i) < 0.5
                z(i+1) = (z(i) - P) / (0.5 - P);
            elseif z(i) >= 0.5 && z(i) < 1 - P
                z(i+1) = (1 - P - z(i)) / (0.5 - P);
            elseif z(i) >= 1 - P && z(i) < 1
                z(i+1) = (1 - z(i)) / P;
            end    
            chaos(i) = z(i) * Value;
        end

    case 'Sine' 
        for i = 1:max_iter
            z(i+1) = sin(pi * z(i));
            chaos(i) = z(i) * Value;
        end

    case 'Singer'  
        u = 1.07;
        for i = 1:max_iter
            z(i+1) = u * (7.86 * z(i) - 23.31 * z(i)^2 + 28.75 * z(i)^3 - 13.302875 * z(i)^4);
            chaos(i) = z(i) * Value;
        end

    case 'Sinusoidal' 
        for i = 1:max_iter
            z(i+1) = 2.3 * z(i)^2 * sin(pi * z(i));
            chaos(i) = z(i) * Value;
        end

    case 'Tent'
        z(1) = 0.6; % Initial value for Tent map
        for i = 1:max_iter
            if z(i) < 0.7
                z(i+1) = z(i) / 0.7;
            else
                z(i+1) = (10 / 3) * (1 - z(i));
            end
            chaos(i) = z(i) * Value;
        end
        otherwise
        error('Unknown chaos type');
end
% chaos=chaos(i);

end

