%  Chatic Crayfish Optimization Algorithm(COA)
%
%  Source codes demo version 1.0                                                                      
%                                                                                                     
%  The 11th Gen Intel(R) Core(TM) i7-11700 processor with the primary frequency of 2.50GHz, 16GB memory, and the operating system of 64-bit windows 11 using matlab2021a.                                                                
%                                                                                                     
%  Author and programmer: Binanda maiti;Saptadeep Biswas.                                                                          
%         e-Mail: binandamath.sch@nita.ac.in;saptadeepmath.sch@nita.ac.in                                                                                                                                                                                                                                              


clear all 
close all
clc

N=100;  %Number of search agents
F_name='F1';     %Name of the test function
T=200;           %Maximum number of iterations
chaos_type=10;
    
[LB,UB,Dim, F_obj]=Get_F(F_name); %Get details of the benchmark functions
% [best_fun2,best_position2,cuve_f2,global_Cov2]=COA(N,T,LB,UB,Dim, F_obj); 
[best_fun2, best_position2, cuve_f2, global_Cov2] = choaticCOA(N, T, LB, UB, Dim, F_obj, chaos_type);

figure('Position',[454   445   694   297]);
subplot(1,3,1); % Corrected 'sUBplot' to 'subplot'
func_plot(F_name);     % Function plot
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([F_name,'( x_1 , x_2 )'])

subplot(1,3,2);       % Convergence plot
semilogy(cuve_f2,'LineWidth',3)
xlabel('Iteration#');
ylabel('Fitness Value');
title('Convergence Curve');

subplot(1,3,3);       % Another convergence plot
semilogy(global_Cov2,'LineWidth',3)
xlabel('Iteration#');
ylabel('Diversity (or coverage)');
title('Global Convergence');
legend('COA');


display(['The best-obtained solution by COA is : ', num2str(best_position2)]);  
display(['The best optimal value of the objective funciton found by COA is : ', num2str(best_fun2)]);  