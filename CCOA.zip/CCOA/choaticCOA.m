function [best_fun2, best_position2, cuve_f2, global_Cov2] = choaticCOA(N, T, LB, UB, Dim, F_obj, chaos_type)
    %% Define Parameters
    disp('CCOA working');
    
    cuve_f2 = zeros(1, T);
    X = initialization(N, Dim, UB, LB); % Initialize population
    global_Cov2 = zeros(1, T);
    Best_fitness = inf;
    best_position2 = zeros(1, Dim);
    fitness_f = zeros(1, N);

    % Valid chaos types
    valid_chaos_types = {'Chebyshev', 'Circle', 'Gauss', 'Iterative', 'Logistic', 'Piecewise', 'Sine', 'Singer', 'Sinusoidal', 'Tent'};

    % Ensure chaos_type is a string
    if iscell(chaos_type)
        chaos_type = chaos_type{1}; % Extract the first element if it's a cell array
    elseif isnumeric(chaos_type)
        % If chaos_type is numeric, convert it to a string representation (if applicable)
        chaos_type = valid_chaos_types{chaos_type}; % Assuming chaos_type is an index to valid types
    end

    % Check the chaos type before using it
    if ~ismember(chaos_type, valid_chaos_types)
        error('Unknown chaos type: %s. Valid types are: %s', chaos_type, strjoin(valid_chaos_types, ', '));
    end

    %% Initial Fitness Evaluation
    for i = 1:N
        fitness_f(i) = F_obj(X(i,:)); % Calculate the fitness value
        if fitness_f(i) < Best_fitness
            Best_fitness = fitness_f(i);
            best_position2 = X(i,:);
        end
    end

    global_position = best_position2;
    global_fitness = Best_fitness;
    cuve_f2(1) = Best_fitness;
    t = 1;

    % Initialize chaos using the selected chaotic map
    max_iter = T; % Set the number of iterations
    Value = 1;
    chaos = chaotic_map1(chaos_type, max_iter, Value); % Generate chaotic sequence

    %% Main Loop
    while t <= T
        C = 2 - (t / T); % Eq.(7)
        temp = chaos(t) * 15 + 20; % Use chaos in temperature
        xf = (best_position2 + global_position) / 2; % Eq.(5)
        Xfood = best_position2;
        Xnew = zeros(N, Dim); % Initialize Xnew

        for i = 1:N
            if temp > 30
                %% Summer Resort Stage
                if chaos(i) < 0.5
                    Xnew(i,:) = X(i,:) + C * chaos(i) * (xf - X(i,:)); % Eq.(6)
                else
                    %% Competition Stage
                    for j = 1:Dim
                        z = round(chaos(i) * (N - 1)) + 1;  % Eq.(9)
                        Xnew(i,j) = X(i,j) - X(z,j) + xf(j);  % Eq.(8)
                    end
                end
            else
                %% Foraging Stage
                P = 3 * chaos(i) * fitness_f(i) / F_obj(Xfood); % Eq.(4)
                if P > 2   % The food is too big
                    Xfood = exp(-1 / P) .* Xfood;   % Eq.(12)
                    for j = 1:Dim
                        Xnew(i,j) = X(i,j) + cos(2 * pi * chaos(i)) * Xfood(j) * p_obj(temp) - sin(2 * pi * chaos(i)) * Xfood(j) * p_obj(temp); % Eq.(13)
                    end
                else
                    Xnew(i,:) = (X(i,:) - Xfood) * p_obj(temp) + p_obj(temp) * chaos(i) .* X(i,:); % Eq.(14)
                end
            end
        end
        
        %% Boundary Conditions
        for i = 1:N
            for j = 1:Dim
                if length(UB) == 1
                    Xnew(i,j) = min(UB, Xnew(i,j));
                    Xnew(i,j) = max(LB, Xnew(i,j));
                else
                    Xnew(i,j) = min(UB(j), Xnew(i,j));
                    Xnew(i,j) = max(LB(j), Xnew(i,j));
                end
            end
        end
        
        %% Fitness Evaluation for New Population
        for i = 1:N
            new_fitness = F_obj(Xnew(i,:));
            if new_fitness < global_fitness
                global_fitness = new_fitness;
                global_position = Xnew(i,:);
            end
            %% Update the Population
            if new_fitness < fitness_f(i)
                fitness_f(i) = new_fitness;
                X(i,:) = Xnew(i,:);
                if fitness_f(i) < Best_fitness
                    Best_fitness = fitness_f(i);
                    best_position2 = X(i,:);
                end
            end
        end

        global_Cov2(t) = global_fitness;
        cuve_f2(t) = Best_fitness;
        t = t + 1;
        
        % Update chaotic sequence
        chaos = chaotic_map1(chaos_type, max_iter, Value);
        
        if mod(t, 100) == 0
            disp("CCOA iter " + num2str(t) + ": " + Best_fitness);
        end
    end
    best_fun2 = Best_fitness;
end


%% Probability Distribution Function
function y = p_obj(x)   % Eq.(4)
    y = 0.2 * (1 / (sqrt(2 * pi) * 3)) * exp(-(x - 25).^2 / (2 * 3.^2));
end
